# Flask MySQL App

Aplicación Flask conectada a MySQL, lista para desplegar en Render o Railway.