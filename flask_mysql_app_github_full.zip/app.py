from flask import Flask, render_template, request, g, redirect, url_for
import mysql.connector
from mysql.connector import Error
import os
from urllib.parse import urlparse

app = Flask(__name__)

def get_db_config():
    db_url = os.environ.get("DATABASE_URL")
    if db_url:
        url = urlparse(db_url)
        return {
            'host': url.hostname,
            'user': url.username,
            'password': url.password,
            'database': url.path[1:] if url.path else None,
            'port': url.port or 3306,
        }
    return {
        'host': os.environ.get('MYSQL_HOST', 'localhost'),
        'user': os.environ.get('MYSQL_USER', 'root'),
        'password': os.environ.get('MYSQL_PASSWORD', ''),
        'database': os.environ.get('MYSQL_DATABASE', 'testdb'),
        'port': int(os.environ.get('MYSQL_PORT', 3306)),
    }

DB_CONFIG = get_db_config()

def get_db_connection():
    try:
        conn = mysql.connector.connect(**DB_CONFIG)
        return conn
    except Error as e:
        app.logger.error(f"Error conectando a la base de datos: {e}")
        return None

@app.before_request
def open_db():
    g.db = get_db_connection()

@app.teardown_request
def close_db(exc):
    db = getattr(g, 'db', None)
    if db is not None:
        try:
            db.close()
        except Exception:
            pass

@app.route('/')
def index():
    if g.db is None:
        return "No hay conexión a la base de datos. Revisa las variables de entorno.", 500

    cursor = g.db.cursor()
    try:
        cursor.execute(
            "CREATE TABLE IF NOT EXISTS usuarios (id INT AUTO_INCREMENT PRIMARY KEY, nombre VARCHAR(255)) ENGINE=InnoDB"
        )
        cursor.execute("SELECT nombre FROM usuarios")
        usuarios = cursor.fetchall()
        return render_template("index.html", usuarios=usuarios)
    finally:
        cursor.close()

@app.route('/agregar', methods=['POST'])
def agregar():
    if g.db is None:
        return "No hay conexión a la base de datos.", 500

    nombre = request.form.get('nombre')
    if not nombre:
        return "Falta el campo 'nombre'", 400

    cursor = g.db.cursor()
    try:
        cursor.execute("INSERT INTO usuarios (nombre) VALUES (%s)", (nombre,))
        g.db.commit()
        return redirect(url_for('index'))
    except Exception as e:
        app.logger.exception("Error al insertar usuario")
        return (f"Error al insertar usuario: {e}", 500)
    finally:
        try:
            cursor.close()
        except Exception:
            pass

@app.route('/db_status')
def db_status():
    return {"connected": g.db is not None, "database": DB_CONFIG.get('database')}

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get('PORT', 8080)))
